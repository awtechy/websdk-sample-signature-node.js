'use strict';

module.exports = require('./dist/zoomus-websdk.umd.min');